package com.fdmgroup.BankingApplication.security;

public enum Role {

	// Maybe change to ROLE_USER, ROLE_ADMIN to comply with standard spring security role naming convention?
    // -- Agree, but What about do it in the last sprint if we have time? 
    // we can create a backlog item but with lowest priority
	
    USER,
    ADMIN

}
